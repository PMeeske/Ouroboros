# 14 – Example Apps, Tutorials & Samples   <!-- Issue #14 -->

**Goal:** Showcase practical usage patterns and integration recipes.

## Tasks
- [ ] End-to-end sample: LLM-powered workflow with tool invocation
- [ ] Minimal quick-start console app
- [ ] Jupyter notebook demo

## Acceptance Criteria
- Samples compile & pass CI
- Linked from README

_Part of #1_