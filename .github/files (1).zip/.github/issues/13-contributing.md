# 13 – Contribution Guidelines & Community Health   <!-- Issue #13 -->

**Goal:** Make it easy for others to contribute safely and effectively.

## Tasks
- [ ] Add `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md`, `SECURITY.md`
- [ ] Configure issue/PR templates
- [ ] Set up stalebot rules

## Acceptance Criteria
- All community-health files present
- New-contributor onboarding guide exists

_Part of #1_